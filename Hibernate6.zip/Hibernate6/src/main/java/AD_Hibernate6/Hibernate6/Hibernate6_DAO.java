package AD_Hibernate6.Hibernate6;


import java.util.List;
import java.util.Scanner;

import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.transaction.Transactional;

@Repository
@Transactional
public class Hibernate6_DAO {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	// Constructor
    public Hibernate6_DAO(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

	public void saveC(Clientes cliente) {
		// TODO Auto-generated method stub
		entityManager.persist(cliente);
	}
	
	public void saveP(Productos producto) {
		// TODO Auto-generated method stub
		entityManager.persist(producto);
	}
	
	public void deleteC(Long clienteId ) {
		// TODO Auto-generated method stub
		Clientes cliente = entityManager.find(Clientes.class, clienteId);
		if (cliente != null) {
			entityManager.remove(cliente);
		}
	}
	
	// Method to delete clients by name
    public static void borrarCliente(String nombre, EntityManager em) {
        // Begin transaction
        em.getTransaction().begin();

        // Create query to retrieve clients with the given name
        Query query = em.createQuery("SELECT c FROM Clientes c WHERE c.nombre = :nombre");
        query.setParameter("nombre", nombre);

        // Execute query and get the list of clients
        List<Clientes> clientesList = query.getResultList();

        // Iterate over the list of clients and remove each one
        for (Clientes cliente : clientesList) {
            em.remove(cliente);
        }

        // Commit the transaction
        em.getTransaction().commit();

        // Print a message indicating the deletion is done
        System.out.println("Clientes con el nombre '" + nombre + "' han sido borrados correctamente.");
    }
	
    @SuppressWarnings("unchecked")
	public List<Clientes> getAllClientes() {
    	
    	// Check if entityManager is null
        if (entityManager == null) {
            throw new IllegalStateException("entityManager is not initialized");
        }
    	//Query query = em.createQuery("SELECT e FROM Professor e");
    	Query query = entityManager.createQuery("select c from Clientes c", Clientes.class);
    	
        return query.getResultList();
    }
    
    // Method to search for the country of the given name
    public static String buscarPaisDe(String nombre, List<Clientes> clientesList) {
        for (Clientes cliente : clientesList) {
            if (cliente.getNombre().equals(nombre)) {
                return cliente.getPais();
            }
        }
        // If no match found, return null or appropriate message
        return "No se encontró el nombre especificado.";
    }
    
 // Method to search for clients from a specific country and print their details
    public static void mostrarPorPais(String pais, List<Clientes> clientesList) {
        int count = 0;
        System.out.println("Clientes en " + pais + ":");
        for (Clientes cliente : clientesList) {
            if (cliente.getPais().equalsIgnoreCase(pais)) {
                count++;
                System.out.println("ID: " + cliente.getId() + ", Nombre: " + cliente.getNombre() + ", Pais: " + cliente.getPais());
            }
        }
        System.out.println("Total de clientes en " + pais + ": " + count);
    }
    
 // Method to update client details by ID
    public static void actualizarCliente(int id, EntityManager em) {
        // Find the client by ID
        Clientes cliente = em.find(Clientes.class, id);
        // Check if the client exists
        if (cliente != null) {
            Scanner scanner = new Scanner(System.in);

            // Display current values
            System.out.println("Valores actuales del cliente:");
            System.out.println("Nombre: " + cliente.getNombre());
            System.out.println("Pais: " + cliente.getPais());

            // Prompt user for new name
            System.out.println("¿Quieres un nuevo nombre? (si/no)");
            String respuestaNombre = scanner.nextLine();
            if (respuestaNombre.equalsIgnoreCase("si")) {
                System.out.println("Introduce el nuevo nombre:");
                String nuevoNombre = scanner.nextLine();
                cliente.setNombre(nuevoNombre);
            }

            // Prompt user for new country
            System.out.println("¿Quieres un nuevo país? (si/no)");
            String respuestaPais = scanner.nextLine();
            if (respuestaPais.equalsIgnoreCase("si")) {
                System.out.println("Introduce el nuevo país:");
                String nuevoPais = scanner.nextLine();
                cliente.setPais(nuevoPais);
            }

            // Commit the transaction to update the client
            em.getTransaction().begin();
            em.getTransaction().commit();
            System.out.println("Cliente actualizado correctamente.");
        } else {
            System.out.println("No se encontró ningún cliente con el ID proporcionado.");
        }
    }
	
	public void deleteP(Long productoId ) {
		// TODO Auto-generated method stub
		Productos producto = entityManager.find(Productos.class, productoId);
		if (producto != null) {
			entityManager.remove(producto);
		}
	}
	
	

}
