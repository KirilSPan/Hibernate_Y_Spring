package AD_Hibernate6.Hibernate6;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

/**
 * Hello world!
 *
 */

public class App {
	public static void main(String[] args) {

		// Crea el EntityManagerFactory usando el nombre de la unidad de persistencia
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("bbdd_spring");

		// Crea el EntityManager
		EntityManager em = emf.createEntityManager();

		// Create an instance of Hibernate6_DAO and pass EntityManager to its
		// constructor
		Hibernate6_DAO dao = new Hibernate6_DAO(em);

		System.out.println("Hello World!");
		// Hibernate6_DAO hib = new Hibernate6_DAO();
//		Clientes cliente = new Clientes();

//        cliente.setId(4);
//        cliente.setNombre("Juan");
//        cliente.setPais("España");

		// hib.getAllClientes();
		// hib.saveC(cliente);
		// Guarda el libro en la base de datos
//        em.getTransaction().begin();
//        //em.persist(cliente); No usar
//        cliente = em.merge(cliente); // Reattach the detached entity
//      em.getTransaction().commit();
		
		// Retrieve all Clientes entities from the database
		List<Clientes> clientesList = dao.getAllClientes();

		
		// Print each Cliente's attributes
        for (Clientes cliente : clientesList) {
            System.out.println("ID: " + cliente.getId() + ", Nombre: " + cliente.getNombre() + ", Pais: " + cliente.getPais());
        }
        
        
//        // Search for the country of the given name
//        String nombreBuscado = "Juan"; // Example name
//        String pais = dao.buscarPaisDe(nombreBuscado, clientesList);
//        System.out.println("El país de " + nombreBuscado + " es: " + pais);
        
//     // Search for clients from a specific country and print their details
//        String paisBuscado = "España"; // Example country
//        dao.mostrarPorPais(paisBuscado, clientesList);
        
        // Example ID to update
//        int idToUpdate = 1; // Change this to the ID you want to update
//        dao.actualizarCliente(idToUpdate, em);
        
//        dao.deleteC((long) 1);
     // Example name to delete
//        String nombreToDelete = "Juan"; // Change this to the name you want to delete
//
//        // Call the method to delete clients with the given name
//        dao.borrarCliente(nombreToDelete, em);
        
		em.close();
		emf.close();
	}
}
